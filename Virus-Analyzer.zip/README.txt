Name: D.S.G. Jayarathne
Index: 140710N


Instructions to run the program:

The target PC must have installed "MySql Server".



 1. Extract the virus-database-sql-file.zip file in the application diretory 
 
2. Open the executable file "Virus-Scanner".
 
3. Give your MySQL credentials of a user that has write permissions

 (It may take approximately two minutes for the MySQL Server to run the SQL script
)
 4. When the Database Sync is completed, Open a file.
 5. The application will compute the MD5 hash value of the file and cross check the
 value with the database containing malcious file definitions.

 6. Results will be displayed in the log list.

EICAR test virus and a real malicious file are included with the
submission due to testing. In order to prevent the malicious file from execution, it is included 
in a password protected zip archive. 

Password for archive: 'password'

The source code of the project is included in the 'Virus_Scanner' folder