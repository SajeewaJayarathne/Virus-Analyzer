﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Security.Cryptography;

namespace Virus_Analyzer
{
    public partial class VirusAnalyzer : Form
    {
        string username;
        string password;
        MySqlConnectionStringBuilder connectionString;
        public VirusAnalyzer()
        {
            InitializeComponent();
        }

        private void VirusScanner_Load(object sender, EventArgs e)
        {
            string[] promptValue = Prompt.ShowDialog("ENTER MYSQL USERNAME AND PASSWORD", "MySql Credentials");         
            if (promptValue != null)
            {
                username = promptValue[0];
                password = promptValue[1];
                string sqlConnectionString = "";

                connectionString = new MySqlConnectionStringBuilder();
                connectionString.UserID = username;
                connectionString.Password = password;
                connectionString.Server = "localhost";
                sqlConnectionString = connectionString.GetConnectionString(true);
                using (MySqlConnection connectinDB = new MySqlConnection(sqlConnectionString))
                {
                    try {
                        connectinDB.Open();
                        string query = "SHOW DATABASES";
                        MySqlCommand command = new MySqlCommand(query, connectinDB);
                        MySqlDataReader dataReader = command.ExecuteReader();
                        Boolean flag = false;
                        while (dataReader.Read())
                        {
                            if (dataReader.GetString(0).Equals("virus_scanner"))
                            {
                                logList.Items.Add(String.Format("{0:T}", DateTime.Now) + ": Database Loaded");
                                flag = true;
                            }
                        }
                        if (!flag)
                        {
                            logList.Items.Add(String.Format("{0:T}", DateTime.Now) + ": Database Sync Started. Please Wait. This may take 2 minutes.");
                            openButton.Enabled = false;
                            StatusDB.Text = "Database Status: Sync in progress. Please Wait.";
                            sqlScript.RunWorkerAsync();
                        }
                        else {
                            StatusDB.Text = "Database Status: Sync Complete";
                        }
                        connectinDB.Close();
                    }catch(Exception ex){
                        MessageBox.Show("In order to run this program, MySql Server must be installed in this PC");
                    }
                }
            }
            else {
                MessageBox.Show("MySql credentials are required to run this program");
                this.Dispose();
            }
        }

        private void sqlScript_Work(object sender, DoWorkEventArgs e)
        {
            
            string sqlConnection = "";
            connectionString = new MySqlConnectionStringBuilder();
            connectionString.UserID = username;
            connectionString.Password = password;
            connectionString.Server = "localhost";
            sqlConnection = connectionString.GetConnectionString(true);
            using (MySqlConnection connectionDB = new MySqlConnection(sqlConnection))
            {
                connectionDB.Open();
                string query = File.ReadAllText("vx.sql");
                MySqlScript script = new MySqlScript(connectionDB, query);
                script.Delimiter = ";";
                script.Execute();
                connectionDB.Close();
            }
        }

        private void sqlScript_ProgressChanged(object sender, ProgressChangedEventArgs e)
        {

        }

        private void sqlScript_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {           
            logList.Items.Add(String.Format("{0:T}", DateTime.Now) + ": Database Sync Finished");
            StatusDB.Text = "Database Status: Sync Complete";
            openButton.Enabled = true;
            this.Show();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }


        private void openButton_Click(object sender, EventArgs e)
        {
            byte[] fileMD5Hash;
            if (openFileDialog1.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                using (var md5 = MD5.Create())
                {
                    logList.Items.Add(String.Format("{0:T}", DateTime.Now) + ": File: "+openFileDialog1.FileName+" opened");
                    using (var stream = File.OpenRead(openFileDialog1.FileName))
                    {
                        fileMD5Hash = md5.ComputeHash(stream);
                    }
                }
                StringConverter converter = new StringConverter();
                logList.Items.Add(String.Format("{0:T}", DateTime.Now) + ": File MD5 Hash: " + converter.ToHex(fileMD5Hash, false));
                searchDatabase(converter.ToHex(fileMD5Hash, false));           
            }
        }



        public string[] searchDatabase(string queryMD5)
        {
            string sqlConnection = "";
            sqlConnection = connectionString.GetConnectionString(true);

            using (MySqlConnection connectionDB = new MySqlConnection(sqlConnection))
            {
                connectionDB.Open();
                MySqlCommand command = new MySqlCommand("SELECT * FROM virus_scanner.vx where vxMD5 = @md5");
                command.Connection = connectionDB;
                command.Parameters.AddWithValue("@md5",queryMD5);
                
                MySqlDataReader dataReader = command.ExecuteReader();
                Boolean flag = false;
                while (dataReader.Read())
                {
                    flag = true;
                    logList.Items.Add("================================================================");
                    logList.Items.Add(String.Format("{0:T}", DateTime.Now) + ": File identified as a malicious file ");
                    logList.Items.Add(String.Format("{0:T}", DateTime.Now) + ": Name: " + dataReader.GetString(3));
                    logList.Items.Add(String.Format("{0:T}", DateTime.Now) + ": Type: " + dataReader.GetString(10));
                    logList.Items.Add("================================================================");


                }
                if (!flag) {
                    logList.Items.Add(String.Format("{0:T}", DateTime.Now) + ": Opened file not identified as a malicious file ");
                    logList.Items.Add("================================================================");
                }
                
                connectionDB.Close();
            }


            return new string[] { };

        }

        private void log_list_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
