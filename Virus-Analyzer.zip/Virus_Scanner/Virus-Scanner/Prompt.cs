﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Virus_Analyzer
{
    class Prompt
    {
        public static string[] ShowDialog(string text, string caption)
        {
            Form prompt = new Form()
            {
                Width = 400,
                Height = 175,
                FormBorderStyle = FormBorderStyle.FixedDialog,
                Text = caption,
                StartPosition = FormStartPosition.CenterScreen,
                MaximizeBox = false,
                MinimizeBox = false
            };

            Label textLabel = new Label() { Left = 50, Top = 20, Width=250, Text = text };
            Label usernameLabel = new Label() { Left = 10, Top = 50, Width = 70, Text = "USERNAME" };
            Label passwordLabel = new Label() { Left = 10, Top = 75, Width = 70, Text = "PASSWORD" };
            TextBox usernameText = new TextBox() { Left = 90, Top = 50, Width = 250 };
            TextBox passwordText = new TextBox() { Left = 90, Top = 75, Width = 250 };
            Button confirm = new Button() { Text = "OK", Left = 240, Width = 100, Top = 100, DialogResult = DialogResult.OK };
            confirm.Click += (sender, e) => { prompt.Close(); };
            prompt.Controls.Add(usernameText);
            prompt.Controls.Add(passwordText);
            prompt.Controls.Add(usernameLabel);
            prompt.Controls.Add(passwordLabel);        
            prompt.Controls.Add(confirm);
            prompt.Controls.Add(textLabel);
            prompt.AcceptButton = confirm;
            string[] retStr = new string[2];            

            return prompt.ShowDialog() == DialogResult.OK ? new string[] {usernameText.Text,passwordText.Text } : null;
        }        
    }
}
