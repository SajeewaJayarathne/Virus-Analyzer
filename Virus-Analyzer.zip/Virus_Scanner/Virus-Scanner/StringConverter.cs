﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Virus_Analyzer
{
    class StringConverter
    {
        public string ToHex(byte[] bytesArray, bool upperCase)
        {
            StringBuilder result = new StringBuilder(bytesArray.Length * 2);

            for (int i = 0; i < bytesArray.Length; i++)
                result.Append(bytesArray[i].ToString(upperCase ? "X2" : "x2"));

            return result.ToString();
        }
    }
}
