﻿namespace Virus_Analyzer
{
    partial class VirusAnalyzer
    {
        
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.sqlScript = new System.ComponentModel.BackgroundWorker();
            this.StatusDB = new System.Windows.Forms.Label();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.openButton = new System.Windows.Forms.Button();
            this.logList = new System.Windows.Forms.ListBox();
            this.SuspendLayout();
            // 
            // sqlScript
            // 
            this.sqlScript.DoWork += new System.ComponentModel.DoWorkEventHandler(this.sqlScript_Work);
            this.sqlScript.ProgressChanged += new System.ComponentModel.ProgressChangedEventHandler(this.sqlScript_ProgressChanged);
            this.sqlScript.RunWorkerCompleted += new System.ComponentModel.RunWorkerCompletedEventHandler(this.sqlScript_RunWorkerCompleted);
            // 
            // StatusDB
            // 
            this.StatusDB.AutoSize = true;
            this.StatusDB.Font = new System.Drawing.Font("Minion Pro Med", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.StatusDB.Location = new System.Drawing.Point(18, 19);
            this.StatusDB.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.StatusDB.Name = "StatusDB";
            this.StatusDB.Size = new System.Drawing.Size(126, 22);
            this.StatusDB.TabIndex = 0;
            this.StatusDB.Text = "Database Status: ";
            this.StatusDB.Click += new System.EventHandler(this.label1_Click);
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            // 
            // openButton
            // 
            this.openButton.Location = new System.Drawing.Point(281, 51);
            this.openButton.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.openButton.Name = "openButton";
            this.openButton.Size = new System.Drawing.Size(173, 42);
            this.openButton.TabIndex = 2;
            this.openButton.Text = "Open Virus File";
            this.openButton.UseVisualStyleBackColor = true;
            this.openButton.Click += new System.EventHandler(this.openButton_Click);
            // 
            // logList
            // 
            this.logList.FormattingEnabled = true;
            this.logList.ItemHeight = 22;
            this.logList.Location = new System.Drawing.Point(22, 103);
            this.logList.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.logList.Name = "logList";
            this.logList.Size = new System.Drawing.Size(704, 312);
            this.logList.TabIndex = 3;
            this.logList.SelectedIndexChanged += new System.EventHandler(this.log_list_SelectedIndexChanged);
            // 
            // VirusAnalyzer
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 22F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(751, 439);
            this.Controls.Add(this.logList);
            this.Controls.Add(this.openButton);
            this.Controls.Add(this.StatusDB);
            this.Font = new System.Drawing.Font("Minion Pro Med", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Name = "VirusAnalyzer";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Virus Scanner";
            this.Load += new System.EventHandler(this.VirusScanner_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.ComponentModel.BackgroundWorker sqlScript;
        private System.Windows.Forms.Label StatusDB;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private System.Windows.Forms.Button openButton;
        private System.Windows.Forms.ListBox logList;
    }
}

